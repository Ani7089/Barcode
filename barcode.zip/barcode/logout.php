<?php
include_once('header.php');
echo "<script>window.location='login.php'</script>";
include_once('footer.php');
?>