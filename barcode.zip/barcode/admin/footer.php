
<!-- Footer -->
<div id="footer">
	<div class="shell">
		<span class="left"></span>
		<span class="right">
			 <a href="http://chocotemplates.com" target="_blank" title="The Sweetest CSS Templates WorldWide"></a>
		</span>
	</div>
</div>
<!-- End Footer -->
	
</body>
</html>