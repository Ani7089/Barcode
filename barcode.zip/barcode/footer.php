</section>
        
        
    	<div class="clear"></div>
    </div>
    <footer class="width">
		<h2 align="center">COLLEGE MANGEMENT</h2>
    </footer>
</div>
</body>
</html>